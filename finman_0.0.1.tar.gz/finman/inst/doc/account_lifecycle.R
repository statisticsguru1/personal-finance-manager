## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tidyverse)
library(finman)

## ----account_creation---------------------------------------------------------
main <- MainAccount$new("Main")
needs <- ChildAccount$new("Needs", allocation = 0.5)
savings <- ChildAccount$new("Savings", allocation = 0.3)
debt <- ChildAccount$new("Debt", allocation = 0.2)

main$add_child_account(needs)
main$add_child_account(savings)
main$add_child_account(debt)
# Simulate overdue
rent <- GrandchildAccount$new("Rent", 
                              freq =1,
                              due_date = Sys.Date() - 6,
                              fixed_amount = 5000,
                              account_type = "Bill")
needs$add_child_account(rent)

## ----account_status-----------------------------------------------------------
rent$status  # "inactive"

## ----account_reactivation-----------------------------------------------------
needs$set_child_allocation("Rent", 0.5)
rent$change_status("active")
rent$status

## ----auto_reactivation--------------------------------------------------------
rent$deposit(10000, channel = "Bank",date = Sys.Date() - 8) # funded days before due
rent$get_account_status()
rent$get_account_periods()

## -----------------------------------------------------------------------------
rent$deposit(1000, channel = "Bank",date = Sys.Date() - 3)
rent$get_account_status()
rent$get_account_periods()

## -----------------------------------------------------------------------------
rent$change_status("active")  # ensure rent is active
main$deposit(20000, channel = "Equity Bank")

rent$get_balance()      # Rent gets funds
needs$get_balance()     # Needs balance reflects leftover after rent
main$get_balance()      # Should be zero if all children are active

## ----priority_checks----------------------------------------------------------
# set child priorities

needs$set_priority(3)
savings$set_priority(2)
debt$set_priority(1)

# deposit money
main$deposit(10000, channel = "Equity Bank",transaction_number = "Trans1")

# distributions order follows priority see timestamps

needstime=needs$transactions%>%filter(TransactionID=="Trans1")
savingstime=savings$transactions%>%filter(TransactionID=="Trans1")
debttime=debt$transactions%>%filter(TransactionID=="Trans1")
sprintf("needs: %s",needstime$Date)
sprintf("savings: %s",savingstime$Date)
sprintf("debt: %s",debttime$Date)


## ----small_deposits-----------------------------------------------------------
main$deposit(0.09, channel = "ABSA",transaction_number = "Test: Small Allocation")


