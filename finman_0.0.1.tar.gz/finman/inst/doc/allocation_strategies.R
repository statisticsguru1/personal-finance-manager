## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(finman)
library(tibble)

## -----------------------------------------------------------------------------
main <- MainAccount$new("Main")

needs <- ChildAccount$new("Needs", allocation = 0.5)
savings <- ChildAccount$new("Savings", allocation = 0.3)
debt <- ChildAccount$new("Debt", allocation = 0.2)

main$add_child_account(needs)
main$add_child_account(savings)
main$add_child_account(debt)

# Tier 3 accounts under Needs
needs$add_child_account(GrandchildAccount$new("Rent", fixed_amount = 8000, freq = 30, due_date = Sys.Date() + 7))
needs$add_child_account(GrandchildAccount$new("Food", fixed_amount = 3000, freq = 30, due_date = Sys.Date() + 7))

# Under Savings
savings$add_child_account(GrandchildAccount$new("Emergency Fund", fixed_amount = 5000, freq = 30, due_date = Sys.Date() + 7))

# Under Debt
debt$add_child_account(GrandchildAccount$new("Student Loan", fixed_amount = 6000, freq = 30, due_date = Sys.Date() + 7))

# Fund the budget
main$deposit(30000, channel = "ABSA")

## -----------------------------------------------------------------------------
main <- MainAccount$new("Main")

debt_recovery <- ChildAccount$new("Debt Recovery", allocation = 0.5)
needs <- ChildAccount$new("Needs", allocation = 0.4)
savings <- ChildAccount$new("Savings", allocation = 0.1)

main$add_child_account(debt_recovery)
main$add_child_account(needs)
main$add_child_account(savings)

debt_recovery$add_child_account(GrandchildAccount$new("Defaulted Loan", fixed_amount = 15000, freq = 30, due_date = Sys.Date()))
debt_recovery$add_child_account(GrandchildAccount$new("Overdue Credit", fixed_amount = 12000, freq = 30, due_date = Sys.Date()))

## -----------------------------------------------------------------------------
main <- MainAccount$new("Main")

main$add_child_account(ChildAccount$new("Needs", allocation = 0.3))
main$add_child_account(ChildAccount$new("Savings", allocation = 0.5))
main$add_child_account(ChildAccount$new("Wants", allocation = 0.2))

# Add savings targets
main$child_accounts$Savings$add_child_account(GrandchildAccount$new("Retirement", fixed_amount = 8000, freq = 30, due_date = Sys.Date() + 30))
main$child_accounts$Savings$add_child_account(GrandchildAccount$new("Land Purchase", fixed_amount = 10000, freq = 60, due_date = Sys.Date() + 60))

## -----------------------------------------------------------------------------
main <- MainAccount$new("Main")

needs <- ChildAccount$new("Needs", allocation = 0.9)
savings <- ChildAccount$new("Savings", allocation = 0.1)
wants <- ChildAccount$new("Wants", allocation = 0.0)

main$add_child_account(needs)
main$add_child_account(savings)
main$add_child_account(wants)

needs$add_child_account(GrandchildAccount$new("Rent", fixed_amount = 7000, freq = 30, due_date = Sys.Date() + 5))
needs$add_child_account(GrandchildAccount$new("Food", fixed_amount = 3000, freq = 30, due_date = Sys.Date() + 5))

