## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tidyverse)
library(finman)

## ----create_tree--------------------------------------------------------------
main <- MainAccount$new("Main")
needs <- ChildAccount$new("Needs", allocation = 0.5)
savings <- ChildAccount$new("Savings", allocation = 0.3)
debt <- ChildAccount$new("Debt", allocation = 0.2)

main$add_child_account(needs)
main$add_child_account(savings)
main$add_child_account(debt)

rent <- GrandchildAccount$new(
  "Rent", freq = 30, due_date = today() + 5, fixed_amount = 5000
)
needs$add_child_account(rent)

## ----allocate_money-----------------------------------------------------------
# Deposit income (in other words allocate money to main account)
main$deposit(20000, channel = "ABSA")

## ----allocation_results-------------------------------------------------------
# balance
main$get_balance()              # balance in main account
needs$get_balance()             # balance in needs account
savings$get_balance()           # balance in savings account
debt$get_balance()              # balance in debt account
rent$get_balance()              # balance in rent account

# Total balance
main$compute_total_balance()    # total balance in main account+its children
                                # this is literary the accumulated money in your
                                # bank account

needs$compute_total_balance()   # total balance in needs account+ its children
                                # what amount in your bank account is there to 
                                # cover needs

savings$compute_total_balance()   # total balance in savings account+ its children
                                  # what amount in your bank account is there to 
                                  # cover savings

debt$compute_total_balance()   # total balance in debt account+ its children
                                  # what amount in your bank account is there to 
                                  # cover debt

rent$compute_total_balance()   # total balance in rent(it has no children)
                               # what amount in your bank account is there to 
                               # cover rent (a sinking fund)
                            

# amount due 
main$compute_total_due()        # Total amount of debt(current+longterm)

needs$compute_total_due()       # Total amount of debt from needs (current+longterm)

savings$compute_total_due()     # Total amount of debt from savings (current+longterm)
                                # thes are unmet fixed savings etc.

rent$compute_total_due()     # Total amount of debt from rent (current+longterm)
                             # this is what you need to pay from the sinking fund
                             # for rent

## ----rent details-------------------------------------------------------------
rent$status

## ----activate_rent------------------------------------------------------------
needs$set_child_allocation("Rent", 0.5)
rent$change_status("active")

## ----allocate_to_low_level----------------------------------------------------
rent$deposit(20000, channel = "Barclays")

## ----see_status---------------------------------------------------------------
rent$get_account_status()

## ----see stats----------------------------------------------------------------
# balance
rent$get_balance()    # get rent balance
needs$get_balance()   # needs(parent) balance has increased by the refund amount

# overall balance
needs$compute_total_balance()  # need account has more money
needs$compute_total_due()  # need total due has decreased
main$compute_total_due()   # even on the whole tree there is decrease
                           # you have reduced total payable.  

## ----advanced_stats-----------------------------------------------------------
main$allocated_amount() # total income allocated
main$spending()         # total spend
main$income_utilization() # utilization of allocated amount?

needs$allocated_amount() # total income allocated to needs
needs$spending()         # how much of the allocation is spend
needs$income_utilization() # utilization level


savings$allocated_amount() # total income allocated to savings
savings$spending()         # how much of the allocation is spend
savings$income_utilization() # utilization level

debt$allocated_amount() # total income allocated to debt
debt$spending()         # how much of the allocation is spend
debt$income_utilization() # utilization level

## ----spend_some_amount--------------------------------------------------------
rent$withdraw(5000,channel="ABSA")      # paid rent
savings$withdraw(6000,channel="ABSA")   # withdraw to pay savings the specifics
                                        # Not known we can specify this by attaching
                                        # which are the specific savings

debt$withdraw(4000,channel="ABSA")      # withdraw to pay savings the specifics

## ----evolution----------------------------------------------------------------
main$allocated_amount() # total income allocated
main$spending()         # total spend
main$income_utilization() # utilization of allocated amount?

needs$allocated_amount() # total income allocated to needs
needs$spending()         # how much of the allocation is spend
needs$income_utilization() # utilization level


savings$allocated_amount() # total income allocated to savings
savings$spending()         # how much of the allocation is spend
savings$income_utilization() # utilization level

debt$allocated_amount() # total income allocated to debt
debt$spending()         # how much of the allocation is spend
debt$income_utilization() # utilization level

