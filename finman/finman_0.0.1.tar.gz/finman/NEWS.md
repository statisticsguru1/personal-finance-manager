# Finance Manager 0.1.0

Initial release with account hierarchy, locking, and JWT-based auth.

# Finance Manager 0.0.1

Setup of account structure and file system backends.
